let ci=0,busy=0,tab=0,cnt=0,SESS=0;
const lv=()=>Math.floor(Math.sqrt(S.xp/15))+1,COLS=['#3d7dff','#8a5cf6','#e14d8a','#d4a03c','#4caf7d','#ff6b1a'];
const card=(it,x='')=>`<div class="it" style="--c:${R[it.r][1]}"><div class="ic">${ICO[it.t](it.c)}</div><span>${it.n}</span>${x}</div>`;
const ACH=[['Первое открытие',()=>S.opens>=1,50],['10 открытий',()=>S.opens>=10,100],['25 открытий',()=>S.opens>=25,300],['100 открытий',()=>S.opens>=100,1000],['250 открытий',()=>S.opens>=250,3000],
['Редкий дроп',()=>S.best>=2,150],['Эпический дроп',()=>S.best>=3,400],['Легендарный дроп',()=>S.best>=4,1000],['Мифический дроп',()=>S.best>=5,5000],
['Коллекция 8',()=>Object.keys(S.col).length>=8,400],['Коллекция 20',()=>Object.keys(S.col).length>=20,1500],['Вся коллекция',()=>Object.keys(S.col).length>=I.length,10000],
['Баланс $1 000',()=>S.bal>=1e3,100],['Баланс $10 000',()=>S.bal>=1e4,500],['Баланс $100 000',()=>S.bal>=1e5,3000],['Уровень 5',()=>lv()>=5,300],['Уровень 10',()=>lv()>=10,1500],
['Создать аккаунт',()=>!!S.acc,100],['Первая сделка',()=>S.st.trades>=1,100],['10 сделок',()=>S.st.trades>=10,500],['Продан лот',()=>S.st.sold>=1,150],['25 проданных лотов',()=>S.st.sold>=25,1500],
['Первый крафт',()=>S.st.crafts>=1,100],['10 крафтов',()=>S.st.crafts>=10,600],['Крит-крафт',()=>S.st.crits>=1,800]];
function toast(t,ok){const e=document.createElement('div');e.textContent=t;e.style.cssText=`position:absolute;left:50%;bottom:30px;transform:translateX(-50%);background:${ok?'#4caf7d':'#c8544a'};color:#fff;padding:10px 16px;border-radius:8px;z-index:30;white-space:nowrap`;$('#app').append(e);setTimeout(()=>e.remove(),2000)}
function chk(){ACH.forEach((a,i)=>{if(!S.ach[i]&&a[1]()){S.ach[i]=1;S.bal+=a[2];toast(`Цель: ${a[0]} +${fmt(a[2])}`,1)}})}
function flash(){const f=document.createElement('div');f.style.cssText='position:absolute;inset:0;background:#fff;z-index:9;pointer-events:none';$('#app').append(f);f.animate([{opacity:.85},{opacity:0}],600).onfinish=()=>f.remove()}
function confetti(r){const m=$('#md');for(let i=0;i<15+r*12;i++){const d=document.createElement('s'),a=Math.random()*6.28,v=120+Math.random()*180;
 d.style.cssText=`position:absolute;left:50%;top:40%;width:7px;height:11px;pointer-events:none;background:${i%2?R[r][1]:'#fff'}`;m.append(d);
 d.animate([{transform:'translate(0,0)',opacity:1},{transform:`translate(${Math.cos(a)*v}px,${Math.sin(a)*v+160}px) rotate(${Math.random()*720}deg)`,opacity:0}],{duration:1400,easing:'ease-out'}).onfinish=()=>d.remove()}}
function ui(){const l=lv(),a=15*(l-1)**2,b=15*l*l,c=C[ci],T=$('#tabs').children,av=$('#av');$('#bal').textContent=fmt(S.bal);$('#lv').textContent='Ур. '+l;$('#xp').style.width=(S.xp-a)/(b-a)*100+'%';$('#cnt').textContent=S.inv.length;
 T[2].classList.toggle('lock',l<2);T[2].textContent=l<2?'Рынок: ур. 2':'Рынок';T[3].classList.toggle('lock',l<4);T[3].textContent=l<4?'Крафт: ур. 4':'Крафт';
 av.textContent=S.acc?S.acc.nick[0].toUpperCase():'?';av.style.background=S.acc?S.acc.col:'#444';
 $('#open').textContent=l<c.lv?'Откроется на уровне '+c.lv:'Открыть за '+fmt(c.p);$('#open').disabled=l<c.lv}
function rc(){const c=C[ci],w=W(c);document.documentElement.style.setProperty('--cc',c.c);$('#cn').textContent=c.n+' кейс';
 $('#cl').innerHTML=C.map((x,i)=>`<button data-i="${i}" class="${i==ci?'on':''}">${x.n}<small>${lv()<x.lv?'ур. '+x.lv:fmt(x.p)}</small></button>`).join('');
 $('#od').innerHTML=w.map((p,i)=>p?`<div style="--c:${R[i][1]}"><u></u>${R[i][0]}<b>${p}%</b></div>`:'').join('')+(w!=c.w?'<p>Первые 5 открытий: повышенные шансы</p>':'');
 stage($('#cs'),caseModel(ci,c.c),1);ui()}
function ri(){$('#gr').innerHTML=S.inv.map((it,i)=>card(it,`<em>${fmt(bid(it.id))}</em>`).replace('class="it"',`class="it" data-i="${i}"`)).join('')||'<p style="grid-column:1/3" class="dim">Пусто. Открой первый кейс.</p>';
 $('#iv').textContent='Оценка: '+fmt(S.inv.reduce((a,b)=>a+bid(b.id),0));
 $('#cc').textContent=Object.keys(S.col).length+'/'+I.length;$('#col').innerHTML=I.map(it=>S.col[it.id]?card(it):card({...it,n:'???',c:'#444'}).replace('class="it"','class="it off"')).join('');
 $('#ac').textContent=Object.keys(S.ach).length+'/'+ACH.length;$('#ach').innerHTML=ACH.map((a,i)=>`<div class="${S.ach[i]?'ok':''}"><span>${a[0]}</span><b>${S.ach[i]?'получено':'+'+fmt(a[2])}</b></div>`).join('');ui()}
function rm(){$('#my').innerHTML=(S.my.length||S.ord.length?'<h3>Мои лоты и заявки</h3>':'')+S.my.map((m,i)=>`<div class="lot"><span>Лот: ${I[m.id].n} · ${Math.max(0,(m.exp-Date.now())/6e4|0)} мин</span><b>${fmt(m.p)}</b><button data-c="m${i}">Снять</button></div>`).join('')+S.ord.map((o,i)=>`<div class="lot"><span>Заявка: ${I[o.id].n}</span><b>${fmt(o.p)}</b><button data-c="o${i}">Отмена</button></div>`).join('');
 $('#mk').innerHTML=[...I].sort((a,b)=>b.r-a.r||b.p-a.p).map(it=>{const h=S.h[it.id],ch=(S.px[it.id]/h[0]-1)*100,up=ch>=0;
 return`<div class="mr" data-id="${it.id}" style="--c:${R[it.r][1]}"><div class="ic">${ICO[it.t](it.c)}</div><span>${it.n}<small>${R[it.r][0]} · лотов ${S.lots[it.id].length}</small></span>${spark(h,up?'#4caf7d':'#c8544a')}<em class="${up?'up':'dn'}">${fmt(S.px[it.id])}<small>${up?'+':''}${ch.toFixed(1)}%</small></em></div>`}).join('');
 $('#feed').innerHTML=S.feed.map(s=>`<div>${s}</div>`).join('')||'<div>Пока тихо</div>'}
function rf(){$('#cf').innerHTML=[0,1,2,3,4].map(r=>{const n=S.inv.filter(x=>x.r==r).length;return`<div class="mr" style="--c:${R[r][1]};cursor:default"><span>${R[r][0]} ×5 → ${R[r+1][0]}<small>В инвентаре: ${n}</small></span><button data-r="${r}" ${n<5?'disabled':''}>Крафт</button></div>`}).join('')}
function modal(it,idx,nw){const m=$('#md'),v=bid(it.id);m.hidden=0;m.className='ov';m.onclick=null;
 m.innerHTML=`<div style="color:${R[it.r][1]};font-weight:700">${R[it.r][0]}</div><h2>${it.n}</h2><div class="stage" id="ms" style="--cc:${R[it.r][1]}"></div><p class="dim">Рынок: ${fmt(S.px[it.id])} · мгновенная продажа ${fmt(v)}</p><button class="btn pri" id="sl">Продать за ${fmt(v)}</button><button class="btn" id="ok" style="margin-top:10px">${nw?'Оставить':'Закрыть'}</button>`;
 const m3=itemModel(it);stage($('#ms'),m3,m3._sc);
 if(nw){confetti(it.r);[600,800,1000].slice(0,it.r>1?3:1).forEach((f,i)=>setTimeout(()=>beep(f,.15,.07),i*120));
  if(it.r>=3){flash();$('#app').animate([{transform:'translate(0)'},{transform:'translate(-6px,4px)'},{transform:'translate(6px,-4px)'},{transform:'translate(0)'}],{duration:80,iterations:6})}}
 const close=()=>{cancelAnimationFrame($('#ms')._f);m.hidden=1;busy=0;view()};
 $('#ok').onclick=close;$('#sl').onclick=()=>{S.bal+=v;mv(it.id,-.006);S.inv.splice(idx,1);chk();save();close()}}
function detail(id){const it=I[id],m=$('#md'),L=S.lots[id],own=S.inv.findIndex(x=>x.id==id);m.hidden=0;m.className='ov top';
 m.innerHTML=`<h2>${it.n}</h2><div style="color:${R[it.r][1]}">${R[it.r][0]}</div><div class="chart">${spark(S.h[id],'#d4a03c',300,90)}</div><p class="dim">Цена ${fmt(S.px[id])} · лотов ${L.length} · ботам сразу ${fmt(bid(id))}</p>
 <div class="lots">${L.map((l,i)=>`<div><span>${l.s}</span><b>${fmt(l.p)}</b><button data-b="${i}">Купить</button></div>`).join('')||'<div>Лотов нет</div>'}</div>
 <div class="frm"><input id="pb" type="number" inputmode="numeric" value="${Math.round(S.px[id]*.95)}"><button class="btn" id="bo">Заявка на покупку</button></div>
 ${own>=0?`<div class="frm"><input id="ps" type="number" inputmode="numeric" value="${Math.round(S.px[id]*1.06)}"><button class="btn" id="so">Выставить (комиссия 10%)</button></div>`:''}<button class="btn" id="ok">Закрыть</button>`;
 m.onclick=e=>{const b=e.target.closest('button');if(!b)return;
  if(b.id=='ok'){m.hidden=1;m.onclick=null;return rm()}
  if(b.dataset.b!=null){const l=S.lots[id][+b.dataset.b];if(S.bal<l.p)return toast('Не хватает денег');S.bal-=l.p;takeLot(id,+b.dataset.b);S.inv.push({...it});S.col[id]=1;S.st.trades++;S.st.spent+=l.p;beep(700,.1)}
  else if(b.id=='bo'){const p=Math.round(+$('#pb').value);if(!(p>0)||p>S.bal)return toast('Неверная цена или мало денег');S.bal-=p;S.ord.push({id,p});fill();toast('Заявка создана',1)}
  else if(b.id=='so'){const p=Math.round(+$('#ps').value);if(!(p>0))return toast('Неверная цена');S.inv.splice(S.inv.findIndex(x=>x.id==id),1);S.my.push({id,p,exp:Date.now()+EXP});toast('Лот выставлен на 15 минут',1)}
  chk();save();ui();detail(id)}}
function accModal(){const m=$('#md');m.hidden=0;m.className='ov';m.onclick=null;let col=COLS[0];const go=()=>{SESS=1;m.hidden=1;m.onclick=null;chk();save();tab=2;view()};
 if(S.acc){m.innerHTML=`<h2>Вход</h2><p class="dim">${S.acc.nick}</p><div class="frm"><input id="pw" type="password" placeholder="Пароль"></div><button class="btn pri" id="go">Войти</button><button class="btn" id="no" style="margin-top:10px">Отмена</button>`;
  $('#go').onclick=()=>hs($('#pw').value)==S.acc.h?go():toast('Неверный пароль')}
 else{m.innerHTML=`<h2>Создать аккаунт</h2><p class="dim">Нужен для торговли на рынке. Данные хранятся только на этом устройстве.</p><div class="frm"><input id="nk" maxlength="14" placeholder="Ник"></div><div class="frm"><input id="pw" type="password" placeholder="Пароль, от 4 символов"></div><div class="sw">${COLS.map((c,i)=>`<i data-c="${c}" class="${i?'':'on'}" style="background:${c}"></i>`).join('')}</div><button class="btn pri" id="go">Создать</button><button class="btn" id="no" style="margin-top:10px">Отмена</button>`;
  m.onclick=e=>{const i=e.target.closest('[data-c]');if(i){col=i.dataset.c;m.querySelectorAll('.sw i').forEach(x=>x.classList.toggle('on',x==i))}};
  $('#go').onclick=()=>{const n=$('#nk').value.trim(),p=$('#pw').value;if(n.length<3)return toast('Ник от 3 символов');if(p.length<4)return toast('Пароль от 4 символов');S.acc={nick:n,col,h:hs(p),since:Date.now()};go()}}
 $('#no').onclick=()=>{m.hidden=1;m.onclick=null}}
function prof(){if(!S.acc)return accModal();const m=$('#md'),a=S.acc,t=S.st;m.hidden=0;m.className='ov';m.onclick=null;
 m.innerHTML=`<div id="pa" style="width:64px;height:64px;border-radius:50%;background:${a.col};display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700">${a.nick[0].toUpperCase()}</div><h2>${a.nick}</h2><p class="dim">С ${new Date(a.since).toLocaleDateString('ru')} · ур. ${lv()}</p>
 <div class="odds" style="width:100%"><div>Открыто кейсов<b>${S.opens}</b></div><div>Сделок на рынке<b>${t.trades}</b></div><div>Продано лотов<b>${t.sold}</b></div><div>Заработано на лотах<b>${fmt(t.earn)}</b></div><div>Потрачено на покупки<b>${fmt(t.spent)}</b></div><div>Крафтов<b>${t.crafts}</b></div></div>
 <button class="btn" id="lo">Выйти из аккаунта</button><button class="btn" id="no" style="margin-top:10px">Закрыть</button>`;
 $('#lo').onclick=()=>{SESS=0;m.hidden=1;if(tab==2){tab=0;view()}};$('#no').onclick=()=>m.hidden=1}
async function roulette(c,w){const ro=$('#ro'),st=$('#strip');ro.hidden=0;$('#rt').textContent=c.n+' кейс';
 st.innerHTML=Array.from({length:60},(_,i)=>i==50?w:pick(c)).map((it,i)=>card(it).replace('class="it"',`class="it" id="c${i}"`)).join('');
 st.style.transition='none';st.style.transform='none';st.offsetWidth;
 const cx=$('#win').clientWidth/2,x=50*102+51+(Math.random()*60-30)-cx;
 st.style.transition='transform 6.5s cubic-bezier(.08,.7,.12,1)';st.style.transform=`translateX(${-x}px)`;
 let last=-1,run=1;(function t(){if(!run)return;const m=new DOMMatrix(getComputedStyle(st).transform).m41,i=Math.floor((cx-m)/102);
  if(i!=last){last=i;beep(500+i%5*40,.03,.04);navigator.vibrate&&navigator.vibrate(8)}requestAnimationFrame(t)})();
 await sl(6700);run=0;$('#c50').classList.add('w');beep(1000,.3,.08);await sl(900);ro.hidden=1}
$('#open').onclick=async()=>{const c=C[ci];if(busy||lv()<c.lv)return;if(S.bal<c.p)return toast('Не хватает денег');
 busy=1;S.bal-=c.p;save();ui();const cs=$('#cs'),lid=cs.firstChild.firstChild._lid;beep(180,.15,.08);
 cs.animate([{transform:'translateX(0)'},{transform:'translateX(-10px) rotate(-3deg)'},{transform:'translateX(10px) rotate(3deg)'},{transform:'translateX(0)'}],{duration:140,iterations:6});
 await sl(850);lid.animate([{transform:'none'},{transform:'translateY(-160px) rotateZ(35deg)'}],{duration:500,fill:'forwards'});flash();beep(900,.2,.08);
 await sl(450);const w=pick(c),l0=lv();await roulette(c,w);
 S.inv.push(w);S.opens++;S.xp+=8+Math.round(c.p/8);S.col[w.id]=1;S.best=Math.max(S.best,w.r);chk();
 if(lv()>l0)toast('Новый уровень: '+lv(),1);save();ui();modal(w,S.inv.length-1,1)};
$('#cl').onclick=e=>{const b=e.target.closest('button');if(b&&!busy){ci=+b.dataset.i;rc()}};
$('#gr').onclick=e=>{const d=e.target.closest('.it');if(d)modal(S.inv[+d.dataset.i],+d.dataset.i,0)};
$('#sellall').onclick=()=>{S.inv.forEach(it=>{S.bal+=bid(it.id);mv(it.id,-.004)});S.inv=[];chk();save();ri()};
$('#mk').onclick=e=>{const r=e.target.closest('.mr');if(r)detail(+r.dataset.id)};
$('#my').onclick=e=>{const b=e.target.closest('button');if(!b)return;const k=b.dataset.c,i=+k.slice(1);
 if(k[0]=='m'){S.inv.push({...I[S.my[i].id]});S.my.splice(i,1)}else{S.bal+=S.ord[i].p;S.ord.splice(i,1)}save();ui();rm()};
$('#cf').onclick=e=>{const b=e.target.closest('button');if(!b||b.disabled)return;const r=+b.dataset.r;
 S.inv.map((x,i)=>[x,i]).filter(([x])=>x.r==r).sort((a,b)=>bid(a[0].id)-bid(b[0].id)).slice(0,5).map(a=>a[1]).sort((a,b)=>b-a).forEach(i=>S.inv.splice(i,1));
 let nr=r+1;const crit=Math.random()<.05&&nr<5;if(crit){nr++;S.st.crits++}S.st.crafts++;S.xp+=10;
 const w={...rnd(I.filter(i=>i.r==nr))};S.inv.push(w);S.col[w.id]=1;S.best=Math.max(S.best,w.r);flash();if(crit)toast('Критический крафт!',1);chk();save();ui();modal(w,S.inv.length-1,1)};
$('#av').onclick=prof;
function view(){[0,1,2,3].forEach(i=>$('#v'+i).hidden=tab!=i);[...$('#tabs').children].forEach((b,i)=>b.classList.toggle('on',i==tab));[rc,ri,rm,rf][tab]()}
$('#tabs').onclick=e=>{const b=e.target.closest('button');if(!b||busy)return;const i=[...$('#tabs').children].indexOf(b);
 if(i==2){if(lv()<2)return toast('Рынок откроется на уровне 2');if(!SESS)return accModal()}
 if(i==3&&lv()<4)return toast('Крафт откроется на уровне 4');tab=i;view()};
setInterval(()=>{cnt++;if(cnt%3==0){botStep();if(tab==2&&$('#md').hidden)rm()}if(cnt%5==0){if(S.bal<50)S.bal+=1;chk();save();ui()}},1000);
view();
