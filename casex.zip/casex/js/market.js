/* Рынок: лоты ботов, лоты и заявки игрока, события. Цена = смесь последних сделок. Коридор 0.5x-2x */
const BOTS=[['Артём','c'],['Vera','c'],['Ghost','c'],['Mira_77','s'],['Kolya','s'],['Борис','s'],['NoobKing','n'],['Dimon','n'],['Tosha','n'],['Ярик','n'],['WhaleX','w']];
const FEE=.1,EXP=9e5;let quiet=0;
const nick=()=>S.acc?S.acc.nick:'Вы',note=s=>{if(!quiet&&typeof toast=='function')toast(s,1)};
const feedAdd=s=>{if(!quiet){S.feed.unshift(s);S.feed.length=Math.min(S.feed.length,14)}};
const hist=id=>{const h=S.h[id];h.push(S.px[id]);if(h.length>40)h.shift()};
function mv(id,pct,who,act){const b=I[id].p;S.px[id]=Math.min(b*2,Math.max(b*.5,S.px[id]*(1+pct)));hist(id);if(who)feedAdd(`${who} ${act}: ${I[id].n}, ${fmt(S.px[id])}`)}
function addLot(id,s,p){const L=S.lots[id];if(L.length<6){L.push({s,p:Math.round(p)});L.sort((a,b)=>a.p-b.p)}}
function takeLot(id,i=0){const l=S.lots[id].splice(i,1)[0];S.px[id]=S.px[id]*.6+l.p*.4;hist(id);return l}
function fill(){S.ord=S.ord.filter(o=>{const L=S.lots[o.id];if(L.length&&L[0].p<=o.p){const l=takeLot(o.id);S.bal+=o.p-l.p;S.inv.push({...I[o.id]});S.col[o.id]=1;S.st.trades++;S.st.spent+=l.p;note('Заявка исполнена: '+I[o.id].n+' за '+fmt(l.p));return false}return true})}
function settle(){S.my=S.my.filter(m=>{if(Date.now()>m.exp){S.inv.push({...I[m.id]});note('Лот истёк: '+I[m.id].n);return false}
 const r=m.p/S.px[m.id];if(Math.random()<(r<=1?.5:r<=1.1?.25:r<=1.25?.06:.01)){const g=Math.round(m.p*(1-FEE));S.bal+=g;S.st.earn+=g;S.st.sold++;S.st.trades++;S.px[m.id]=S.px[m.id]*.7+m.p*.3;hist(m.id);feedAdd(`${nick()} продал ${I[m.id].n} за ${fmt(m.p)}`);note('Продан лот: '+I[m.id].n+' +'+fmt(g));return false}return true})}
function botStep(){const [n,t]=rnd(BOTS),pool=t=='c'?I.filter(i=>i.r>=2):t=='n'?I.filter(i=>i.r<=1):I,id=rnd(pool).id,L=S.lots[id];
 if(t=='w'){if(Math.random()<.2){if(Math.random()<.5){while(L.length)takeLot(id);mv(id,.08,n,'скупил все лоты')}else mv(id,-.08,n,'слил партию')}}
 else if(t=='c'||(t=='s'&&S.px[id]<I[id].p*.95)){if(L.length&&L[0].p<=S.px[id]*1.12){const l=takeLot(id);feedAdd(`${n} купил ${I[id].n} у ${l.s} за ${fmt(l.p)}`)}else mv(id,.012)}
 else addLot(id,n,S.px[id]*(1.02+Math.random()*.12));
 S.lots.forEach((L,k)=>{while(L.length&&L[L.length-1].p>S.px[k]*1.3)L.pop();if(Math.random()<.02)L.pop()});
 I.forEach(i=>S.px[i.id]+=(i.p-S.px[i.id])*.01);
 if(Math.random()<.004){const r=rnd([0,1,2,3,4,5]),up=Math.random()<.5;I.filter(i=>i.r==r).forEach(i=>mv(i.id,up?.1:-.1));feedAdd('Событие: '+(up?'спрос на ':'распродажа ')+R[r][0].toLowerCase()+' предметы')}
 settle();fill()}
quiet=1;if(S.lots.every(L=>!L.length))for(let i=0;i<120;i++)botStep();
for(let i=0,n=Math.min(300,(Date.now()-S.t)/3000|0);i<n;i++)botStep();quiet=0;
const spark=(h,c,w=60,hh=22)=>{const mn=Math.min(...h),d=(Math.max(...h)-mn)||1,n=Math.max(h.length-1,1);return`<svg viewBox="0 0 ${w} ${hh}" width="${w==60?60:'100%'}" height="${hh}"><polyline fill="none" stroke="${c}" stroke-width="${w==60?1.6:2}" points="${h.map((v,i)=>`${i/n*w},${hh-2-(v-mn)/d*(hh-4)}`).join(' ')}"/></svg>`};
