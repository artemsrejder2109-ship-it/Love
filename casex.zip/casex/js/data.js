const $=s=>document.querySelector(s),sl=ms=>new Promise(r=>setTimeout(r,ms)),rnd=a=>a[Math.random()*a.length|0],fmt=n=>'$'+Math.round(n).toLocaleString('ru');
const R=[['Обычный','#6b7280'],['Необычный','#3d7dff'],['Редкий','#8a5cf6'],['Эпический','#e14d8a'],['Легендарный','#d4a03c'],['Мифический','#ff6b1a']];
const I=[['Ржавый нож','k',0,15,'#a0a7b5'],['Охотничий нож','k',0,19,'#b8a07a'],['Серый пистолет','p',0,12,'#8d97b5'],
['Стальной клинок','k',1,55,'#9fb4d0'],['Синий пистолет','p',1,70,'#3d7dff'],['Винтовка Лазурь','r',1,60,'#2a9df4'],
['Плазменный резак','k',2,220,'#8a5cf6'],['Неоновая винтовка','r',2,260,'#4de3c8'],['Керамбит','k',2,280,'#c05cf6'],
['Клинок бури','k',3,620,'#e14d8a'],['Пистолет Токсин','p',3,580,'#7ee03a'],['Винтовка Дракон','r',3,700,'#ff5a36'],
['Экскалибур','k',4,2200,'#f3d27a'],['Клинок пустоты','k',4,2800,'#6a5cff'],['Золотая винтовка','r',4,2400,'#d4a03c'],
['Деревянная дубина','a',0,10,'#8b6b4a'],['Ржавая каска','h',0,14,'#7a7f8a'],['Тканевая маска','m',0,11,'#9aa0aa'],
['Боевой топор','a',1,58,'#5a8fd0'],['Тактический шлем','h',1,62,'#4a6fa5'],['Кованый меч','s',1,66,'#6fa0d8'],['Кристалл-шар','o',1,50,'#3dc7ff'],
['Меч рыцаря','s',2,240,'#a77cff'],['Кибер-визор','h',2,255,'#4de3c8'],['Ядро аномалии','o',2,230,'#c05cf6'],['Маска Тени','m',2,270,'#8a5cf6'],['Секира бури','a',2,285,'#7a6cff'],
['Корона стражей','c',3,690,'#e14d8a'],['Топор палача','a',3,640,'#ff5a8a'],['Шлем завоевателя','h',3,720,'#ff7a5a'],['Драконье око','o',3,610,'#ff5a36'],
['Корона королей','c',4,2500,'#f3d27a'],['Тень богов','m',4,2600,'#d4a03c'],['Меч Джека','s',5,6500,'#ff6b1a'],['Корона Самайна','c',5,9000,'#ff9a3a']].map(([n,t,r,p,c],id)=>({id,n,t,r,p,c}));
const C=[{n:'Стартовый',p:50,lv:1,c:'#3d7dff',w:[74,21,4.5,.4,.1,0]},{n:'Премиум',p:250,lv:3,c:'#8a5cf6',w:[0,58,34,6.5,1.5,0]},{n:'Элитный',p:1000,lv:6,c:'#d4a03c',w:[0,0,45,38,17,0]},{n:'Мифический',p:3000,lv:9,c:'#ff6b1a',w:[0,0,0,45,45,10]}];
const ICO={s:c=>`<svg viewBox="0 0 64 32"><path d="M18 16L60 11v10z" fill="${c}"/><rect x="14" y="6" width="4" height="20" fill="#555b6b"/><rect x="2" y="13" width="12" height="6" rx="2" fill="#3a3f4d"/></svg>`,
a:c=>`<svg viewBox="0 0 64 32"><rect x="6" y="14" width="48" height="4" fill="#6b5a45"/><path d="M38 5h14l5 11-5 11H38c5-7 5-15 0-22z" fill="${c}"/></svg>`,
h:c=>`<svg viewBox="0 0 64 32"><path d="M12 26v-9c0-9 8-13 20-13s20 4 20 13v9z" fill="${c}"/><rect x="18" y="16" width="28" height="5" fill="#14161c"/></svg>`,
o:c=>`<svg viewBox="0 0 64 32"><circle cx="32" cy="15" r="12" fill="${c}"/><circle cx="28" cy="11" r="3" fill="#fff" opacity=".5"/><rect x="21" y="26" width="22" height="4" rx="2" fill="#3a3f4d"/></svg>`,
c:c=>`<svg viewBox="0 0 64 32"><path d="M10 27V7l11 9 11-12 11 12 11-9v20z" fill="${c}"/><rect x="10" y="24" width="44" height="3" fill="#000" opacity=".3"/></svg>`,
m:c=>`<svg viewBox="0 0 64 32"><path d="M12 4h40v13c0 9-8 13-20 13S12 26 12 17z" fill="${c}"/><path d="M19 11l9 4-9 3zM45 11l-9 4 9 3z" fill="#14161c"/></svg>`,
k:c=>`<svg viewBox="0 0 64 32"><path d="M20 20L52 6l8 8-30 8z" fill="${c}"/><rect x="4" y="19" width="18" height="7" rx="2" fill="#3a3f4d"/><rect x="19" y="14" width="4" height="16" fill="#555b6b"/></svg>`,
p:c=>`<svg viewBox="0 0 64 32"><rect x="10" y="8" width="46" height="10" rx="2" fill="${c}"/><rect x="14" y="16" width="13" height="14" rx="2" fill="#3a3f4d"/><rect x="28" y="18" width="12" height="3" fill="#3a3f4d"/></svg>`,
r:c=>`<svg viewBox="0 0 64 32"><rect x="14" y="10" width="40" height="8" rx="2" fill="${c}"/><rect x="2" y="12" width="14" height="14" rx="2" fill="#3a3f4d"/><rect x="50" y="12" width="12" height="4" fill="#3a3f4d"/><rect x="26" y="18" width="8" height="12" fill="#3a3f4d"/><rect x="24" y="5" width="16" height="5" rx="1" fill="#555b6b"/></svg>`};
/* состояние: px - рыночная цена, h - история цен, col - коллекция */
let S={bal:300,inv:[],xp:0,opens:0,best:0,col:{},ach:{},px:I.map(i=>i.p),h:I.map(i=>[i.p]),feed:[],t:Date.now(),acc:null,lots:I.map(()=>[]),my:[],ord:[],st:{trades:0,earn:0,spent:0,sold:0,crafts:0,crits:0}};
try{S={...S,...JSON.parse(localStorage.casex2)}}catch(e){}
const hs=s=>{let h=5381;for(const c of s)h=(h*33^c.charCodeAt(0))>>>0;return h};
const save=()=>{S.t=Date.now();try{localStorage.casex2=JSON.stringify(S)}catch(e){}};
/* экономика: мгновенная продажа ботам -12%, лоты игроков -10% комиссии, кейсы возвращают ~75-80% */
const bid=id=>Math.max(1,Math.round(S.px[id]*.88));
const W=c=>S.opens<5&&c.p<=50?[40,35,17,6,2,0]:c.w;
function pick(c){const w=W(c);let x=Math.random()*100,t=0;for(;t<5&&(x-=w[t])>=0;t++);return{...rnd(I.filter(i=>i.r==t))}}
let ac;function beep(f,d=.04,v=.05){try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();const o=ac.createOscillator(),g=ac.createGain();o.frequency.value=f;g.gain.value=v;o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+d)}catch(e){}}
