/* 3D из CSS: box = параллелепипед, cyl = призма (цилиндр), mk = группа деталей */
const el=()=>{const e=document.createElement('div');e.className='bx';return e};
function box(w,h,d,x,y,z,col){const e=el();e.style.transform=`translate3d(${x}px,${y}px,${z}px)`;
 [[`translateZ(${d/2}px)`,w,h,1],[`rotateY(180deg) translateZ(${d/2}px)`,w,h,.6],[`rotateY(90deg) translateZ(${w/2}px)`,d,h,.8],[`rotateY(-90deg) translateZ(${w/2}px)`,d,h,.7],[`rotateX(90deg) translateZ(${h/2}px)`,w,d,1.25],[`rotateX(-90deg) translateZ(${h/2}px)`,w,d,.5]].forEach(([t,fw,fh,b])=>{
  const f=document.createElement('i');f.style.cssText=`width:${fw}px;height:${fh}px;margin:${-fh/2}px 0 0 ${-fw/2}px;background:${col};filter:brightness(${b});transform:${t}`;e.append(f)});return e}
function cyl(r,h,x,y,z,col,n=10){const e=el(),sw=2*r*Math.sin(Math.PI/n)+.8,ap=r*Math.cos(Math.PI/n),pts=Array.from({length:n},(_,k)=>`${50+50*Math.cos(6.2832*k/n)}% ${50+50*Math.sin(6.2832*k/n)}%`).join(',');
 e.style.transform=`translate3d(${x}px,${y}px,${z}px)`;
 for(let i=0;i<n;i++){const f=document.createElement('i');f.style.cssText=`width:${sw}px;height:${h}px;margin:${-h/2}px 0 0 ${-sw/2}px;background:${col};filter:brightness(${.65+.4*Math.cos(i/n*6.2832)});transform:rotateY(${i*360/n}deg) translateZ(${ap}px)`;e.append(f)}
 [['rotateX(90deg)',1.25],['rotateX(-90deg)',.5]].forEach(([a,b])=>{const f=document.createElement('i');f.style.cssText=`width:${2*r}px;height:${2*r}px;margin:${-r}px 0 0 ${-r}px;background:${col};filter:brightness(${b});clip-path:polygon(${pts});-webkit-clip-path:polygon(${pts});transform:${a} translateZ(${h/2}px)`;e.append(f)});return e}
function mk(x=0,y=0,z=0,rz=0){const g=el();g.style.transform=`translate3d(${x}px,${y}px,${z}px) rotateZ(${rz}deg)`;
 g.b=(w,h,d,x,y,z,c)=>(g.append(box(w,h,d,x,y,z,c)),g);g.c=(r,h,x,y,z,c,n)=>(g.append(cyl(r,h,x,y,z,c,n)),g);g.s=(x,y,z,rz)=>{const s=mk(x,y,z,rz);g.append(s);return s};return g}
const SC={k:1.5,p:1.5,r:1.15,s:1.2,a:1.3,h:1.9,o:2,c:2,m:1.9};
function itemModel(it){const g=mk(),c=it.c,d='#262b42',m='#8a93a8',w='#fffc',t=it.t;
 if(t=='k'){g.b(46,14,3,22,0,0,c).b(14,8,3,52,3,0,c).b(40,2,3.6,22,0,0,'#0006').b(4,26,10,-4,0,0,d).b(34,11,9,-24,0,0,'#3a2a20').b(3,12,10,-16,0,0,d).b(3,12,10,-26,0,0,d).b(3,12,10,-34,0,0,d).b(6,13,11,-43,0,0,c)}
 else if(t=='p'){g.b(76,15,12,0,-8,0,c).b(70,3,5,0,-17,0,w).b(12,7,7,44,-8,0,m).b(60,8,10,-4,3,0,d).b(4,4,5,-34,-17,0,d).b(3,4,5,36,-17,0,d).b(18,3,7,6,9,0,d).b(3,9,7,14,6,0,d);g.s(-26,16,0,-10).b(16,34,11,0,0,0,d).b(17,4,12,0,14,0,c)}
 else if(t=='r'){g.b(70,16,12,0,-2,0,c).b(60,2,5,0,-11,0,w).b(34,12,13,50,0,0,d).b(30,5,5,82,-2,0,m).b(40,8,8,10,-17,0,d).b(8,10,10,-6,-17,0,m).b(8,10,10,28,-17,0,m);g.s(-52,6,0,-6).b(40,20,10,0,0,0,d).b(6,24,11,-20,0,0,c);g.s(8,22,0,8).b(13,28,8,0,0,0,d);g.s(-22,16,0,-14).b(11,20,9,0,0,0,d)}
 else if(t=='s'){g.b(84,12,3,28,0,0,c).b(14,7,3,76,0,0,c).b(76,2,3.6,28,0,0,'#fff6').b(5,36,9,-16,0,0,d).b(6,6,12,-16,-18,0,c).b(6,6,12,-16,18,0,c).b(30,8,8,-34,0,0,'#3a2a20').b(8,12,12,-52,0,0,c)}
 else if(t=='a'){g.b(10,100,10,0,0,0,'#6b5a45').b(12,6,12,0,22,0,d).b(12,6,12,0,38,0,d).b(34,28,8,18,-34,0,c).b(10,44,8,36,-34,0,'#fff6').b(14,10,7,-12,-34,0,d)}
 else if(t=='h'){g.c(28,14,0,6,0,c,12).c(26,14,0,-8,0,c,12).c(21,12,0,-21,0,c,12).c(13,10,0,-32,0,c,12).c(26,10,0,18,0,d,12).b(40,9,3,0,-4,26,'#0d0f16').b(4,10,36,0,-42,0,d)}
 else if(t=='o'){[8,15,20,22,20,15,8].forEach((r,k)=>g.c(r,8,0,-24+k*8,0,c,12));g.c(22,6,0,34,0,d,10).c(14,6,0,29,0,m,10)}
 else if(t=='c'){g.c(26,16,0,8,0,c,12).c(27,4,0,17,0,d,12).b(8,8,4,0,8,26,'#fff');for(let k=0;k<6;k++){const a=k*1.0472,x=24*Math.cos(a),z=24*Math.sin(a);g.b(6,18,6,x,-8,z,c).b(4,4,4,x,-20,z,'#fff')}}
 else{g.b(44,52,8,0,0,0,c).b(12,6,2,-11,-8,5,'#0d0f16').b(12,6,2,11,-8,5,'#0d0f16').b(6,14,5,0,6,6,d).b(26,4,2,0,22,5,'#0d0f16');g.s(-22,10,0,0).b(8,20,9,0,0,0,d);g.s(22,10,0,0).b(8,20,9,0,0,0,d);g.s(-24,-30,0,-25).b(6,22,6,0,0,0,d);g.s(24,-30,0,25).b(6,22,6,0,0,0,d)}
 g._sc=SC[t];return g}
function caseModel(i,col){const g=mk(),l=mk(),gold='#ffd24d';
 if(i==0){g.b(150,64,100,0,12,0,'#3a2d20').b(12,66,104,-45,12,0,col).b(12,66,104,45,12,0,col);l.b(158,22,108,0,-30,0,'#4a3a2a').b(30,24,110,0,-30,0,col).b(24,16,4,0,-24,55,gold)}
 else if(i==1){g.c(52,70,0,10,0,'#1d2340',10).c(54,8,0,-8,0,col,10).c(54,8,0,28,0,col,10);l.c(54,14,0,-33,0,'#262d55',10).c(10,10,0,-45,0,col,6)}
 else if(i==2){g.b(160,60,100,0,14,0,'#2b2f45').b(10,64,104,-70,14,0,gold).b(10,64,104,70,14,0,gold).b(162,8,102,0,36,0,gold);l.b(166,24,106,0,-28,0,'#3a3f5a').b(30,26,108,0,-28,0,col).b(20,18,4,0,-14,55,gold)}
 else{g.c(46,80,0,5,0,'#241532',6).c(48,8,0,-12,0,col,6).c(48,8,0,26,0,col,6);l.c(50,10,0,-40,0,col,6);[8,12,14,12,8].forEach((r,k)=>l.c(r,6,0,-50-k*6,0,'#fff',10))}
 g.append(l);g._lid=l;return g}
function stage(el,m,sc){cancelAnimationFrame(el._f);el.innerHTML='';const r=document.createElement('div');r.className='bx';r.append(m);el.append(r);
 let a=30,dr=0,lx;el.onpointerdown=e=>{dr=1;lx=e.clientX};el.onpointermove=e=>{if(dr){a+=(e.clientX-lx)*.8;lx=e.clientX}};el.onpointerup=el.onpointercancel=()=>dr=0;
 (function f(){if(!dr)a+=.6;r.style.transform=`scale(${sc}) rotateX(-18deg) rotateY(${a}deg)`;el._f=requestAnimationFrame(f)})()}
